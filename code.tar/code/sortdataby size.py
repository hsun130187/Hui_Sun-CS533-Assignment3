'''
After I seperrated the data for ecah particular program, I wrote this program to
sort my data my matrix size and wtote them in a different file so that the data for the same size are bunched up tegother.
This will make is convinient to calculate mean and standard deviation for each data point.
'''
import numpy as np
import matplotlib.pyplot as plt

f=open('julia_library.txt','r')
olist1=[]
for line in f.readlines():
    sdata=line.split()
    olist1.append(sdata)
    

f.close

for i in olist1:
    i[2]=int(i[2])
    #print(i)
##The fillowing is the key step for this program. Just sort the data by matrix size. 
M=sorted(olist1, key=lambda x : x[2])
#print(M)
##write the results onto a different file. 
f=open('sort_julia_library.txt','w')
for i in M:
    for j in i:
        f.write(str(j)+"\t")
    f.write("\n")
f.close()



