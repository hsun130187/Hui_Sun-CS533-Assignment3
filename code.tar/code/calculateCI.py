
'''
This file is used to calculate CI of each matrix size for a particular program
and print the confidence intervals out.
'''
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import scipy
from scipy.stats import norm

#The following is the function used to calculate and print 95%confidence interval of an array
def ci_t (data,confidence=0.95):
    sample_mean = np.mean(data)
    sample_std = np.std(data,ddof=1)    
    sample_size = len(data)
    alpha = 1 - confidence
    t_score = scipy.stats.t.isf(alpha / 2, df = (sample_size-1) )
 
    ME = t_score * sample_std / np.sqrt(sample_size)
    lower_limit = sample_mean - ME
    upper_limit = sample_mean + ME
 
    print( str(confidence*100)+ '%% Confidence Interval: (%.2f, %.2f)' % (lower_limit, upper_limit))
    return lower_limit, upper_limit


f=open('sort_c_col.txt','r')
olist1=[]
for line in f.readlines():
    sdata=line.split()[3]
##    sdata=line.split()[5]
    olist1.append(sdata)
f.close()

#print(olist1)
list1=[]
for i in olist1:
    list1.append(float (i))
#print(len(list1))
print(list1)
a=[31, 32, 96, 97, 127, 128, 129, 191, 192, 229, 255, 256, 257,
    319, 320, 321, 417, 479, 480, 511, 512, 639, 640, 767, 768, 769,1000]

meanlist=[]
strrlist=[]
start=0
last=30
step=30
"""
The following will calculate CI every 30 data and get 27 confidence intervals in final. 
"""
for i in range (27):
    templist=[]
    for temp in range(start,last):
        templist.append(list1[temp])
    print("i is %d" % i)
    #print(i+'\n')
    ci_t(templist)
    mean=np.mean(templist)
    std=np.std(templist,ddof=1)
    #print(std)
    meanlist.append(mean)
    strrlist.append(std)
    start+=step
    last+=step

