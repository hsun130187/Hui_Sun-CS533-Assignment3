''''
This program is used to get the mean and standard deviation for every data point. And save the
values in seperate files.(save the mean in mean_***.txt and standard deviation is stored in
the file str_***.txt)
''''
import numpy as np
import matplotlib.pyplot as plt
#open a already sorted file so that the data for a specific matrix size
#are bunched up together. 
f=open('sort_julia_basic.txt','r')
olist1=[]
for line in f.readlines():
    sdata=line.split()[5]
    ##Julia is different with C. when reading julia files, we get the
    ##value with index of 5. Reading C files should get the values with
    ##index of 3.
    #sdata=line.split()[3]
    olist1.append(sdata)
    #olist1.extend(line.split()[3])
    #print(sdata)

f.close()
## change the type of the data to float so that we can calculate mean and standard
##deviation.
print(olist1)
list1=[]
for i in olist1:
    list1.append(float (i))
print(len(list1))

a=[31, 32, 96, 97, 127, 128, 129, 191, 192, 229, 255, 256, 257,
    319, 320, 321, 417, 479, 480, 511, 512, 639, 640, 767, 768, 769,1000]
#meanlist is used to store all the 27 mean values when the loop is done
#strrlist is used to store all the 27 standard deviation values when the loop is done.
#
meanlist=[]
strrlist=[]
start=0
last=30
##step means that every 30 values are in one unit. 
step=30

for i in range (27):
    templist=[]
    for temp in range(start,last):
        templist.append(list1[temp])
    #print(templist)
    mean=np.mean(templist)
    std=np.std(templist,ddof=1)
    #print(std)
    meanlist.append(mean)
    strrlist.append(std)
    start+=step
    last+=step
print(meanlist)
#print(strrlist)

##wrrite the saved mean and standard deeviation values to a file so that
#we can use later. 
file=open('mean_juliabasic.txt','w')
for data in meanlist:
    file.write(str(data)+"\n")

file.close()
file=open('str_juliabasic.txt','w')
for data in strrlist:
    file.write(str(data)+"\n")
file.close()
'''
The folowing code is not importmant. I just wrote this to get a basic of the picture. 
##plt.xlabel("matrix size")
##plt.ylabel("time used/ms")
##plt.plot(a,meanlist)
##plt.title("julia_basic")
##plt.show()

'''
