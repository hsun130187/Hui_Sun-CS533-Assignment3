import numpy as np
import matplotlib.pyplot as plt
from collections import OrderedDict
'''
This is the program I used to plot all the data into one figure. Just read the data
one by one and then plot them. 
'''
linestyles = OrderedDict(
    [('solid',               (0, ())),
     ('loosely dotted',      (0, (1, 10))),
     ('dotted',              (0, (1, 5))),
     ('densely dotted',      (0, (1, 1))),

     ('loosely dashed',      (0, (5, 10))),
     ('dashed',              (0, (5, 5))),
     ('densely dashed',      (0, (5, 1))),

     ('loosely dashdotted',  (0, (3, 10, 1, 10))),
     ('dashdotted',          (0, (3, 5, 1, 5))),
     ('densely dashdotted',  (0, (3, 1, 1, 1))),

     ('loosely dashdotdotted', (0, (3, 10, 1, 10, 1, 10))),
     ('dashdotdotted',         (0, (3, 5, 1, 5, 1, 5))),
     ('densely dashdotdotted', (0, (3, 1, 1, 1, 1, 1)))])

f=open('mean_basic.txt','r')
olist1=[]
for line in f.readlines():
    olist1.append(line)
f.close

#print(olist1)
list1=[]
for i in olist1:
    list1.append(float (i))
#print(list1)
#print(len(list1))


f=open('mean_naive.txt','r')
olist2=[]
for line in f.readlines():
    olist2.append(line)
f.close

#print(olist1)
list2=[]
for i in olist2:
    list2.append(float (i))
#print(list2)
#print(len(list2))


f=open('mean_col.txt','r')
olist3=[]
for line in f.readlines():
    olist3.append(line)
f.close

#print(olist1)
list3=[]
for i in olist3:
    list3.append(float (i))
print(list3)
print(len(list3))

f=open('mean_copy.txt','r')
olist4=[]
for line in f.readlines():
    olist4.append(line)
f.close

#print(olist1)
list4=[]
for i in olist4:
    list4.append(float (i))
print(list4)
print(len(list4))

f=open('mean_blas.txt','r')
olist5=[]
for line in f.readlines():
    olist5.append(line)
f.close

#print(olist1)
list5=[]
for i in olist5:
    list5.append(float (i))
#print(list5)
print(len(list5))

f=open('mean_autovect.txt','r')
olist6=[]
for line in f.readlines():
    olist6.append(line)
f.close

#print(olist1)
list6=[]
for i in olist6:
    list6.append(float (i))
#print(list5)
print(len(list6))
f=open('mean_genvect.txt','r')
olist7=[]
for line in f.readlines():
    olist7.append(line)
f.close

#print(olist1)
list7=[]
for i in olist7:
    list7.append(float (i))
#print(list5)
print(len(list7))
f=open('mean_row.txt','r')
olist8=[]
for line in f.readlines():
    olist8.append(line)
f.close

#print(olist1)
list8=[]
for i in olist8:
    list8.append(float (i))

print(len(list8))
f=open('mean_blocked.txt','r')
olist9=[]
for line in f.readlines():
    olist9.append(line)
f.close

#print(olist1)
list9=[]
for i in olist9:
    list9.append(float (i))

print(len(list9))
f=open('mean_rb.txt','r')
olist10=[]
for line in f.readlines():
    olist10.append(line)
f.close

#print(olist1)
list10=[]
for i in olist10:
    list10.append(float (i))

print(len(list10))

f=open('mean_julialibrary.txt','r')
olist11=[]
for line in f.readlines():
    olist11.append(line)
f.close

#print(olist1)
list11=[]
for i in olist11:
    list11.append(float (i))

print(len(list11))

f=open('mean_juliabasic.txt','r')
olist12=[]
for line in f.readlines():
    olist12.append(line)
f.close

#print(olist1)
list12=[]
for i in olist12:
    list12.append(float (i))

print(len(list12))

a=[31, 32, 96, 97, 127, 128, 129, 191, 192, 229, 255, 256, 257,
    319, 320, 321, 417, 479, 480, 511, 512, 639, 640, 767, 768, 769,1000]
'''
The following steps is to make the plot. I tried diffent ways so some code are commented out.
'''
'''
plt.plot(a,list1,color='blue',label='C_basic',linestyle=linestyles['solid'])
plt.plot(a,list2,color='red',label='C_naive',linestyle=linestyles['densely dotted'])
plt.plot(a,list3,color='purple',label='C_col',linestyle=linestyles['loosely dotted'])
plt.plot(a,list4,color='orange',label='C_copy',linestyle=linestyles['loosely dashed'])
plt.plot(a,list5,color='black',label='C_blas',linestyle=linestyles['dashed'])
plt.plot(a,list6,color='green',label='C_autovect',linestyle=linestyles['densely dashed'])
plt.plot(a,list7,color='yellow',label='C_genvect',linestyle=linestyles['loosely dashdotted'])
plt.plot(a,list8,color='cyan',label='C_row',linestyle=linestyles['dashdotted'])
plt.plot(a,list9,color='magenta',label='C_blocked',linestyle=linestyles['densely dashdotted'])
plt.plot(a,list10,color='brown',label='C_rb',linestyle=linestyles['loosely dashdotdotted'])
plt.plot(a,list11,color='chocolate',label='julia_library', linestyle=linestyles['dashdotdotted'])
plt.plot(a,list12,color='crimson',label='julia_bassic',linestyle=linestyles['densely dashdotdotted'])
'''
##plt.plot(a,list4,color='orange',label='C_copy')
##plt.plot(a,list6,color='green',label='C_autovect',linestyle=linestyles['densely dotted'])
##plt.plot(a,list7,color='yellow',label='C_genvect')
##plt.plot(a,list8,color='cyan',label='C_row')
##plt.plot(a,list9,color='magenta',label='C_blocked')
##plt.plot(a,list10,color='black',label='C_rb')
##plt.plot(a,list11,color='chocolate',label='julia_library')
##plt.plot(a,list1,color='black',label='C_basic',linestyle=linestyles['solid'],marker='_')
##plt.plot(a,list2,color='black',label='C_naive',linestyle=linestyles['densely dotted'],marker='4')
##plt.plot(a,list3,color='black',label='C_col',linestyle=linestyles['loosely dotted'],marker='3')
##plt.plot(a,list4,color='black',label='C_copy',linestyle=linestyles['loosely dashed'],marker='1')
##plt.plot(a,list5,color='black',label='C_blas',linestyle=linestyles['dashed'],marker='2')
plt.plot(a,list6,color='black',label='C_autovect',linestyle=linestyles['densely dashed'],marker='p')
plt.plot(a,list7,color='black',label='C_genvect',linestyle=linestyles['loosely dashdotted'],marker='*')
plt.plot(a,list8,color='black',label='C_row',linestyle=linestyles['dashdotted'],marker='h')
plt.plot(a,list9,color='black',label='C_blocked',linestyle=linestyles['densely dashdotted'],marker='+')
plt.plot(a,list10,color='black',label='C_rb',linestyle=linestyles['loosely dashdotdotted'],marker='|')
plt.plot(a,list11,color='black',label='julia_library', linestyle=linestyles['dashdotdotted'],marker='<')
##plt.plot(a,list12,color='black',label='julia_bassic',linestyle=linestyles['densely dashdotdotted'],marker='s')

plt.title('time used under different methonds and matrix sizes')
plt.legend(loc='upper left')
plt.xlabel("matrix size")
plt.ylabel("time used")
plt.show()

