
'''
This is the file uesd to calculate p values for each matrix size doing t test on
two programs. I need to get the mean and standard deciation for each program. And then
calculate T statistics in order to calculate p value. 
'''
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import scipy
a=[31, 32, 96, 97, 127, 128, 129, 191, 192, 229, 255, 256, 257,
    319, 320, 321, 417, 479, 480, 511, 512, 639, 640, 767, 768, 769,1000]
##read mean and store them in an array
f=open('mean_col.txt','r')
olist1=[]
for line in f.readlines():
    olist1.append(line)
f.close()


list1=[]
for i in olist1:
    list1.append(float (i))

f=open('mean_juliabasic.txt','r')
olist2=[]
for line in f.readlines():
    olist2.append(line)
f.close()


list2=[]
for i in olist2:
    list2.append(float (i))
#print(list2)
#read standard deviation and store them in an array
f=open('str_col.txt','r')
sstdd1=[]
for line in f.readlines():
    sstdd1.append(line)
f.close()

stdd1=[]
for i in sstdd1:
    stdd1.append(float (i))
#print (stdd_basic)
f=open('str_juliabasic.txt','r')
sstdd2=[]
for line in f.readlines():
    sstdd2.append(line)
f.close()

stdd2=[]
for i in sstdd2:
    stdd2.append(float (i))


list3=[]
for i in range (27):
    c=list2[i]-list1[i]
    list3.append(c)
print(list3)
temp1=np.sqrt(1/15)
sw=[]
for i in range (27):
    tem=29*np.square(stdd2[i])+29*np.square(stdd1[i])
    tem=tem/58
    sw.append(np.sqrt(tem))
t=[]
#this is the array to store the t statistics value for each comparision point. 
for i in range (27):
    result=list3[i]/(sw[i]*temp1)
    t.append(result)
print("result is"+"\n")
print(t)
pvalues=[]
#key step to calculate p values.
t_score = scipy.stats.t.isf(0.025, df = (58) )
print("t score is "+"\n")
print(t_score)
print('pvalues')
for i in range (27):
    tt=t[i]
    pval = stats.t.sf(np.abs(tt), 58)*2
    pvalues.append(pval)
print(pvalues)

