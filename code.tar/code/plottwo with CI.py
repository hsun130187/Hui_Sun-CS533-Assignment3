'''
This program is used to make comparison between two particular programs and plot the mean with confidence interval. 

'''
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import scipy
f=open('mean_basic.txt','r')
olist1=[]
for line in f.readlines():
    olist1.append(line)
f.close()


list1=[]
for i in olist1:
    list1.append(float (i))

f=open('mean_naive.txt','r')
olist2=[]
for line in f.readlines():
    olist2.append(line)
f.close()


list2=[]
for i in olist2:
    list2.append(float (i))
#print(list2)

f=open('str_basic.txt','r')
sstdd_basic=[]
for line in f.readlines():
    sstdd_basic.append(line)
f.close()

stdd_basic=[]
for i in sstdd_basic:
    stdd_basic.append(float (i))
#print (stdd_basic)
f=open('str_naive.txt','r')
sstdd_naive=[]
for line in f.readlines():
    sstdd_naive.append(line)
f.close()

stdd_naive=[]
for i in sstdd_naive:
    stdd_naive.append(float (i))
#print (stdd_naive)

def cl (stdd_basic,confidence=0.99):
    err=[]
    alpha=1-confidence
    t_score = scipy.stats.t.isf(alpha / 2, df = (29) )
    for i in range(27):
        temp=(stdd_basic[i]/np.sqrt(30))*t_score
        err.append(temp)
    return err

err1=cl(stdd_basic,confidence=0.99)
err2=cl(stdd_naive,confidence=0.99)

list3=[]

for i in range (27):
    c=list2[i]-list1[i]
    list3.append(c)
print(list3)

a=[31, 32, 96, 97, 127, 128, 129, 191, 192, 229, 255, 256, 257,
    319, 320, 321, 417, 479, 480, 511, 512, 639, 640, 767, 768, 769,1000]
for i in range(27):
    a[i]*=1
##plt.hist(list3)
##plt.show()
#plt.plot(a,list1,color='blue',label='C_basic',linestyle='--')#
#plt.plot(a,list2,color='red',label='C_naive',linestyle='-')

plt.errorbar(a,list1,yerr=err1[i],color='blue',label='C_basic',linestyle='--')
plt.errorbar(a,list2,yerr=err2[i],color='red',label='C_naive',linestyle='-')
plt.legend(loc='upper right')
plt.xlabel("matrix size")
plt.ylabel("time used/ms")
plt.show()


