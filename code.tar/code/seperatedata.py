import numpy as np
import matplotlib.pyplot as plt
'''
This is the program I used to seperate data for each program. 
After this is done. I got 12 different txt files which is corresponding
to a specific C or julia program. 


'''
##
##data0419.txt is the file I got from wheeler. There are total 30 repetations. And I need to make the data bunched up for
#each program and wrote the data on the corresponding file.
##some code is commented out because I need change my code for almost every program. 
f=open('data0419.txt','r')
file=open('c_naive.txt','w')
olist1=[]
##str1="matrix multiplication using basic Julia"
##str2="matrix multiplication using basic Julia"
##if str1 in str2:
##    print("true")
#s="Description:	DGEMM cache blocked 32 * 32 * 32 and register blocked 2 * 2"
line=f.readline()
##while line:
##    if line.startswith("Description:	DGEMM cache blocked/packed 96 * 32 * 32 and register blocked 2 * (2*16/4)"):
##        for i in range (27):
##            datawant=f.readline()
##            file.write(str(datawant))
##    line=f.readline()
##file.close()
##f.close()
'''
while line:
    if line.startswith("Description:	DGEMM cache blocked/packed 96 * 32 * 32 and register blocked 2 * (2*16/4)"):
        for i in range (27):
            f.readline()
        f.readline()
        line=f.readline()
        if line.startswith("Description:	DGEMM with unoptimized loop index order"):
             for i in range (27):
                datawant=f.readline()
                file.write(str(datawant))
    line=f.readline()
file.close()
f.close()
'''
while line:
    if line.startswith("Description:	DGEMM with unoptimized loop index order"):
        for i in range (27):
            f.readline()
        f.readline()
        line=f.readline()
        if line.startswith("Description:	DGEMM with unoptimized loop index order"):
             for i in range (27):
                datawant=f.readline()
                file.write(str(datawant))
    line=f.readline()
file.close()
f.close()
